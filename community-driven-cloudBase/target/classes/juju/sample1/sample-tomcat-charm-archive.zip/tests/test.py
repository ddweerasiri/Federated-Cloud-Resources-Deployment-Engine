#!/usr/bin/python

import logging
import os.path
import subprocess
import unittest
import urllib2

logging.basicConfig(level=logging.DEBUG)

class Tomcat7Test(unittest.TestCase):

    def testOpenSSHDaemon(self):
        cmd = ["pgrep", "sshd"]
        logging.debug("Cmd: %s" % (cmd))
        output = subprocess.Popen(cmd, stdout=subprocess.PIPE).communicate()[0]
        logging.debug("Cmd output: %s" % (output))
        self.assertNotEquals(output, "")

    def testTomcatDefaultPage(self):
        fh = urllib2.urlopen('http://localhost:8080')
        self.assertNotEquals(fh, None)
        output = fh.read()
        logging.debug("Output: %s" % (output))
        self.assertTrue('It works !' in output, output)
        fh.close()

    def testTomcatServlet(self):
        fh = urllib2.urlopen(\
            'http://localhost:8080/examples/servlets/servlet/HelloWorldExample')
        self.assertNotEquals(fh, None)
        output = fh.read()
        logging.debug("Output: %s" % (output))
        self.assertTrue('Hello World!' in output, output)
        fh.close()

    def testTomcatJsp(self):
        fh = urllib2.urlopen(\
             'http://localhost:8080/examples/jsp/jsp2/simpletag/hello.jsp')
        self.assertNotEquals(fh, None)
        output = fh.read()
        logging.debug("Output: %s" % (output))
        self.assertTrue('Hello, world!' in output, output)
        fh.close()

if __name__ == '__main__':
    unittest.main()
