#!/bin/bash

RESULTS_DIR=$1

# Always run from the current test directory 
# this allows subunit et al to work OK.
cd $(dirname $0)

# Set umask so other users can actually read the
# results
umask 0022

# Setup the test results directory
[ -d $RESULTS_DIR ] || mkdir -p $RESULTS_DIR

# Execute the actual testing.
python -m subunit.run test 2> $RESULTS_DIR/TEST-error.log \
    | subunit2junitxml > $RESULTS_DIR/TEST-results.xml 

# Return exit code 0 and test failures cause trigger to fail
exit 0
