# Overview

[Apache Tomcat](http://tomcast.apache.org) is an open source implementation of
the Java Servlet and JavaServer Pages (JSP) specifications, and provides a
"pure Java" HTTP web server environment for Java web applications to run.

Apache Tomcat 7 implements the Java Servlet 3.0 and JSP 2.2 specifications
from the Java Community Process.

## Known Limitations and Issues

The tomcat7 charm  has been replaced by another charm with more features.  The
[tomcat](http://manage.jujucharms.com/precise/tomcat) charm contains all
features of the tomcat7 charm with additional functionality and additional
configuration options. We recommend switching to this new charm, this charm is
in the charm store for historical reasons. 

# Usage

A simple deployment consists of a Tomcat service:

    juju deploy tomcat7

That deploys Apache Tomcat version 7 on an Ubuntu image.

To expose Tomcat to the Internet:

    juju expose tomcat7

You can then browse to http://tomat7-ip-address:8080 to see the default Tomcat
page.

The Apache Tomcat software contains a Web Application Manager that allows
remote deployment of web applications.  This process requires authentication
and this charm defaults to username='admin' password='admin'

# Configuration

This charm allows the configuration of the admin username and admin password.
The manager webapp is password protected 

    juju set tomcat7 admin_username=<username> juju set tomcat7
admin_password=<password>

## Testing

Go to http://tomcat7-ip-address:8080/manager to access the Tomcat Web
Application Manager. Authenticate with the admin username and password that
was set in the tomcat7 configuration.

Got to http://tomcat7-ip-address:8080/host-manager for the Tomcat Virtual Host
Manager. Authenticate with the admin username and password set in the
configuration.

## Scale out Usage

You can deploy the tomcat7 charm in a cluster by using multicast.  By default,
static membership is used over multicast based membership which means units
depend on local cluster configuration to determine cluster groups.  Multicast
uses multicast UDP packets on a pre-determined address/port to determine
cluster groups.  Where a cloud provider such as EC2 disables multicast traffic
between instances, static membership must be used.  Where multicast traffic is
allowed, it is preferred and may be enabled as follows:

    # enable multicast clustering
    juju set tomcat7 multicast=True

    # set multicast address
    juju set tomcat7 multicast_address=228.0.0.4

    # set multicast port
    juju set tomcat7 multicast_port=34569


# Contact Information

This charm was originally created by Juan Negron <juan.negron@canonical.com>.

# Apache Tomcat Project Information

- [Apache Tomcat home page](http://tomcat.apache.org)
- [Apache Tomcat Mailing Lists](http://tomcat.apache.org/lists.html)
- [Tomcat Wiki](http://wiki.apache.org/tomcat/FrontPage)
- [Tomcat 7.0
  Documentation](http://tomcat.apache.org/tomcat-7.0-doc/index.html)
- [Reporting Apache Tomcat Bugs](http://tomcat.apache.org/bugreport.html)
